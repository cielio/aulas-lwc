import { LightningElement, api, track } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import consultarCEP from "@salesforce/apex/ConsultaCEPController.consultarCEP";
import atualizarEnderecoConta from "@salesforce/apex/ConsultaCEPController.atualizarEnderecoConta";
import { ShowToastEvent } from "lightning/platformShowToastEvent";

export default class ConsultaCEP extends NavigationMixin(LightningElement) {
  @api recordId;
  @track isModalOpen = false;
  @track cep;
  @track endereco = {
    cep: "",
    logradouro: "",
    localidade: "",
    uf: "",
    bairro: "",
    numero: ""
  };

  consultarCEP() {
    consultarCEP({ cep: this.cep })
      .then((result) => {
        this.endereco.cep = result.cep;
        this.endereco.logradouro = result.logradouro;
        this.endereco.localidade = result.localidade;
        this.endereco.uf = result.uf;
        this.endereco.bairro = result.bairro;

        this.handleToast(
          "Sucesso!",
          "Consulta realizada com Sucesso",
          "success"
        );
        console.log("Sucesso " + JSON.stringify(result));
        console.log("recordId " + JSON.stringify(this.recordId));
      })
      .catch((error) => {
        this.handleToast("Erro!", "Digite um CEP válido", "error");
        console.log("Error" + error);
      });
  }

  atualizarEnderecoConta() {
    atualizarEnderecoConta({
      consultaCEPTO: this.endereco,
      recordId: this.recordId
    })
      .then((result) => {
        this.closeModal();
        this.navigateToObjectHome();
        this.handleToast(
          "Sucesso!",
          "Endereço da Conta Atualizo com Sucesso",
          "success"
        );
        console.log("Sucesso " + JSON.stringify(result));
      })
      .catch((error) => {
        this.handleToast(
          "Erro!",
          "Erro ao tentar atualizo o endereço da Conta",
          "error"
        );
        console.log("Error" + error);
      });
  }

  handleCEP(event) {
    const inputValue = event.target.value;
    const regex = /^[0-9]*$/; // Regex para aceitar apenas números
    if (regex.test(inputValue)) {
        this.cep = event.target.value;
    }
    event.target.value = this.cep;
    console.log("cep: " + JSON.stringify(this.cep));
  }

  handleInputChange(event) {
    const fieldName = event.target.name;
    this.endereco[fieldName] = event.target.value;
    console.log("endereço: " + JSON.stringify(this.endereco));
  }

  handleToast(title, message, variant) {
    const toastEvent = new ShowToastEvent({
      title: title,
      message: message,
      variant: variant
    });
    this.dispatchEvent(toastEvent);
  }

  openModal() {
    this.isModalOpen = true;
  }
  closeModal() {
    
    this.isModalOpen = false;
  }

  navigateToObjectHome() {
    // Navigate to the Account home page
    this[NavigationMixin.Navigate]({
      type: "standard__recordPage",
      attributes: {
        objectApiName: "Account",
        recordId: this.recordId,
        actionName: "view"
      }
    });
  }
  
}
